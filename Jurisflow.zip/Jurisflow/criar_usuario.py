import sqlite3

conexao = sqlite3.connect("jurisflow.db")

cursor = conexao.cursor()

cursor.execute("""
INSERT INTO usuarios (nome, email, senha)
VALUES (?, ?, ?)
""", (
    "Administrador",
    "admin@jurisflow.com",
    "123456"
))

conexao.commit()
conexao.close()

print("Usuário criado com sucesso!")