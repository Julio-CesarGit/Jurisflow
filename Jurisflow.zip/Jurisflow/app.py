
from flask import Flask, render_template, request, redirect, session, send_from_directory

import sqlite3
import os
from werkzeug.utils import secure_filename



app = Flask(__name__)



app.secret_key = "chave-secreta-jurisflow"





# =========================================

# CRIAR TABELA DE PROCESSOS

# =========================================



def criar_tabela_processos():



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        CREATE TABLE IF NOT EXISTS processos (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            numero TEXT NOT NULL,

            titulo TEXT NOT NULL,

            cliente_id INTEGER,

            tipo TEXT,

            status TEXT,

            vara TEXT,

            descricao TEXT,

            FOREIGN KEY (cliente_id) REFERENCES clientes(id)

        )

    """)



    conexao.commit()

    conexao.close()



# =========================================

# CRIAR TABELA DE PRAZOS

# =========================================



def criar_tabela_prazos():



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        CREATE TABLE IF NOT EXISTS prazos (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            titulo TEXT NOT NULL,

            processo_id INTEGER,

            data_vencimento TEXT NOT NULL,

            prioridade TEXT,

            status TEXT,

            observacao TEXT,

            FOREIGN KEY (processo_id) REFERENCES processos(id)

        )

    """)



    conexao.commit()

    conexao.close()





# =========================================
# PÁGINA INICIAL
# =========================================

@app.route("/")
def inicio():

    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()

    cursor.execute("SELECT COUNT(*) FROM clientes")
    total_clientes = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM processos")
    total_processos = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM prazos")
    total_prazos = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM documentos")
    total_documentos = cursor.fetchone()[0]

    conexao.close()

    return render_template(
        "index.html",
        total_clientes=total_clientes,
        total_processos=total_processos,
        total_prazos=total_prazos,
        total_documentos=total_documentos
    )


# =========================================
# LOGIN
# =========================================

@app.route("/login", methods=["GET", "POST"])
def login():

    erro = None
    email_digitado = ""

    if request.method == "POST":

        email_digitado = request.form.get("email", "").strip()
        senha = request.form.get("senha", "")

        conexao = sqlite3.connect("jurisflow.db")
        cursor = conexao.cursor()

        cursor.execute(
            "SELECT * FROM usuarios WHERE email = ? AND senha = ?",
            (email_digitado, senha)
        )

        usuario = cursor.fetchone()

        conexao.close()

        if usuario:

            session["usuario_id"] = usuario[0]
            session["usuario_nome"] = usuario[1]
            session["usuario_email"] = usuario[2]

            return redirect("/dashboard")

        else:
            erro = "E-mail ou senha incorretos. Verifique seus dados e tente novamente."

    return render_template(
        "login.html",
        erro=erro,
        email_digitado=email_digitado
    )





# =========================================
# DASHBOARD
# =========================================

@app.route("/dashboard")
def dashboard():

    if "usuario_id" not in session:
        return redirect("/login")

    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()

    # =========================================
    # TOTAIS DO BANCO DE DADOS
    # =========================================

    cursor.execute("SELECT COUNT(*) FROM clientes")
    total_clientes = cursor.fetchone()[0] or 0

    cursor.execute("SELECT COUNT(*) FROM processos")
    total_processos = cursor.fetchone()[0] or 0

    cursor.execute("SELECT COUNT(*) FROM prazos")
    total_prazos = cursor.fetchone()[0] or 0

    cursor.execute("SELECT COUNT(*) FROM documentos")
    total_documentos = cursor.fetchone()[0] or 0


    # =========================================
    # PROCESSOS POR STATUS
    # =========================================

    cursor.execute("""
        SELECT
            LOWER(TRIM(COALESCE(status, ''))) AS status,
            COUNT(*)
        FROM processos
        GROUP BY LOWER(TRIM(COALESCE(status, '')))
    """)

    processos_status = cursor.fetchall()

    processos_em_andamento = 0
    processos_concluidos = 0
    processos_pendentes = 0
    processos_arquivados = 0

    for status, quantidade in processos_status:

        if status == "em andamento":
            processos_em_andamento += quantidade

        elif status in ("concluído", "concluido"):
            processos_concluidos += quantidade

        elif status == "pendente":
            processos_pendentes += quantidade

        elif status == "arquivado":
            processos_arquivados += quantidade


    # =========================================
    # PRAZOS POR STATUS
    # =========================================

    cursor.execute("""
        SELECT
            LOWER(TRIM(COALESCE(status, ''))) AS status,
            COUNT(*)
        FROM prazos
        GROUP BY LOWER(TRIM(COALESCE(status, '')))
    """)

    prazos_status = cursor.fetchall()

    prazos_pendentes = 0
    prazos_concluidos = 0

    for status, quantidade in prazos_status:

        if status in ("pendente", "aberto", "em aberto"):
            prazos_pendentes += quantidade

        elif status in (
            "concluído",
            "concluido",
            "finalizado"
        ):
            prazos_concluidos += quantidade


    # =========================================
    # PRAZOS PRÓXIMOS
    # PRÓXIMOS 7 DIAS
    # =========================================

    cursor.execute("""
        SELECT COUNT(*)
        FROM prazos
        WHERE date(data_vencimento)
        BETWEEN date('now', 'localtime')
        AND date('now', 'localtime', '+7 days')
        AND LOWER(TRIM(COALESCE(status, ''))) NOT IN (
            'concluído',
            'concluido',
            'finalizado'
        )
    """)

    prazos_proximos = cursor.fetchone()[0] or 0


    # =========================================
    # PRAZOS ATRASADOS
    # =========================================

    cursor.execute("""
        SELECT COUNT(*)
        FROM prazos
        WHERE date(data_vencimento) < date('now', 'localtime')
        AND LOWER(TRIM(COALESCE(status, ''))) NOT IN (
            'concluído',
            'concluido',
            'finalizado'
        )
    """)

    prazos_atrasados = cursor.fetchone()[0] or 0


    # =========================================
    # DOCUMENTOS VINCULADOS A PROCESSOS
    # =========================================

    cursor.execute("""
        SELECT COUNT(*)
        FROM documentos
        WHERE processo_id IS NOT NULL
    """)

    documentos_vinculados = cursor.fetchone()[0] or 0


    # =========================================
    # DOCUMENTOS SEM ARQUIVO
    # =========================================

    cursor.execute("""
        SELECT COUNT(*)
        FROM documentos
        WHERE nome_arquivo IS NULL
        OR nome_arquivo = ''
    """)

    documentos_sem_arquivo = cursor.fetchone()[0] or 0


    # =========================================
    # PROCESSOS RECENTES
    # =========================================

    cursor.execute("""
        SELECT
            processos.id,
            processos.numero,
            processos.titulo,
            clientes.nome,
            processos.status
        FROM processos
        LEFT JOIN clientes
            ON processos.cliente_id = clientes.id
        ORDER BY processos.id DESC
        LIMIT 5
    """)

    processos_recentes = cursor.fetchall()


    # =========================================
    # PRAZOS MAIS PRÓXIMOS
    # =========================================

    cursor.execute("""
        SELECT
            prazos.id,
            prazos.titulo,
            processos.numero,
            prazos.data_vencimento,
            prazos.prioridade,
            prazos.status
        FROM prazos
        LEFT JOIN processos
            ON prazos.processo_id = processos.id
        ORDER BY date(prazos.data_vencimento) ASC
        LIMIT 5
    """)

    prazos_recentes = cursor.fetchall()


    # =========================================
    # DOCUMENTOS RECENTES
    # =========================================

    cursor.execute("""
        SELECT
            documentos.id,
            documentos.titulo,
            documentos.tipo,
            processos.numero,
            documentos.data_documento
        FROM documentos
        LEFT JOIN processos
            ON documentos.processo_id = processos.id
        ORDER BY documentos.id DESC
        LIMIT 5
    """)

    documentos_recentes = cursor.fetchall()


    # =========================================
    # FECHAR CONEXÃO
    # =========================================

    conexao.close()


    # =========================================
    # ENVIAR DADOS PARA O DASHBOARD
    # =========================================

    return render_template(
        "dashboard.html",

        total_clientes=total_clientes,
        total_processos=total_processos,
        total_prazos=total_prazos,
        total_documentos=total_documentos,

        processos_em_andamento=processos_em_andamento,
        processos_concluidos=processos_concluidos,
        processos_pendentes=processos_pendentes,
        processos_arquivados=processos_arquivados,

        prazos_pendentes=prazos_pendentes,
        prazos_concluidos=prazos_concluidos,
        prazos_proximos=prazos_proximos,
        prazos_atrasados=prazos_atrasados,

        documentos_vinculados=documentos_vinculados,
        documentos_sem_arquivo=documentos_sem_arquivo,

        processos_recentes=processos_recentes,
        prazos_recentes=prazos_recentes,
        documentos_recentes=documentos_recentes
    )





# =========================================

# LOGOUT

# =========================================



@app.route("/logout")

def logout():



    session.clear()



    return redirect("/login")





# =========================================

# LISTA DE CLIENTES

# =========================================



@app.route("/clientes")

def clientes():



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT id, nome, cpf, telefone, email

        FROM clientes

        ORDER BY id DESC

    """)



    clientes = cursor.fetchall()



    conexao.close()



    return render_template(

        "clientes.html",

        clientes=clientes

    )





# =========================================

# NOVO CLIENTE

# =========================================



@app.route("/novo-cliente", methods=["GET", "POST"])

def novo_cliente():



    if "usuario_id" not in session:

        return redirect("/login")



    if request.method == "POST":



        nome = request.form["nome"]

        cpf = request.form["cpf"]

        telefone = request.form["telefone"]

        email = request.form["email"]

        endereco = request.form["endereco"]



        conexao = sqlite3.connect("jurisflow.db")

        cursor = conexao.cursor()



        cursor.execute("""

            INSERT INTO clientes

            (nome, cpf, telefone, email, endereco)

            VALUES (?, ?, ?, ?, ?)

        """, (

            nome,

            cpf,

            telefone,

            email,

            endereco

        ))



        conexao.commit()

        conexao.close()



        return redirect("/clientes")



    return render_template("novo_cliente.html")





# =========================================

# VISUALIZAR CLIENTE

# =========================================



@app.route("/visualizar-cliente/<int:id>")

def visualizar_cliente(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT id, nome, cpf, telefone, email, endereco

        FROM clientes

        WHERE id = ?

    """, (id,))



    cliente = cursor.fetchone()



    conexao.close()



    if cliente is None:

        return "Cliente não encontrado."



    return render_template(

        "visualizar_cliente.html",

        cliente=cliente

    )





# =========================================

# EDITAR CLIENTE

# =========================================



@app.route("/editar-cliente/<int:id>", methods=["GET", "POST"])

def editar_cliente(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    if request.method == "POST":



        nome = request.form["nome"]

        cpf = request.form["cpf"]

        telefone = request.form["telefone"]

        email = request.form["email"]

        endereco = request.form["endereco"]



        cursor.execute("""

            UPDATE clientes

            SET nome = ?,

                cpf = ?,

                telefone = ?,

                email = ?,

                endereco = ?

            WHERE id = ?

        """, (

            nome,

            cpf,

            telefone,

            email,

            endereco,

            id

        ))



        conexao.commit()

        conexao.close()



        return redirect(f"/visualizar-cliente/{id}")



    cursor.execute("""

        SELECT id, nome, cpf, telefone, email, endereco

        FROM clientes

        WHERE id = ?

    """, (id,))



    cliente = cursor.fetchone()



    conexao.close()



    if cliente is None:

        return "Cliente não encontrado."



    return render_template(

        "editar_cliente.html",

        cliente=cliente

    )





# =========================================

# EXCLUIR CLIENTE

# =========================================



@app.route("/excluir-cliente/<int:id>", methods=["POST"])

def excluir_cliente(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute(

        "DELETE FROM clientes WHERE id = ?",

        (id,)

    )



    conexao.commit()

    conexao.close()



    return redirect("/clientes")





# ==================================================

# MÓDULO DE PROCESSOS

# ==================================================





# =========================================

# LISTA DE PROCESSOS

# =========================================



@app.route("/processos")

def processos():



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT

            processos.id,

            processos.numero,

            processos.titulo,

            clientes.nome,

            processos.tipo,

            processos.status,

            processos.vara

        FROM processos

        LEFT JOIN clientes

            ON processos.cliente_id = clientes.id

        ORDER BY processos.id DESC

    """)



    processos = cursor.fetchall()



    conexao.close()



    return render_template(

        "processos.html",

        processos=processos

    )





# =========================================

# NOVO PROCESSO

# =========================================



@app.route("/novo-processo", methods=["GET", "POST"])

def novo_processo():



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    if request.method == "POST":



        numero = request.form["numero"]

        titulo = request.form["titulo"]

        cliente_id = request.form["cliente_id"]

        tipo = request.form["tipo"]

        status = request.form["status"]

        vara = request.form["vara"]

        descricao = request.form["descricao"]



        cursor.execute("""

            INSERT INTO processos

            (numero, titulo, cliente_id, tipo, status, vara, descricao)

            VALUES (?, ?, ?, ?, ?, ?, ?)

        """, (

            numero,

            titulo,

            cliente_id,

            tipo,

            status,

            vara,

            descricao

        ))



        conexao.commit()

        conexao.close()



        return redirect("/processos")



    cursor.execute("""

        SELECT id, nome

        FROM clientes

        ORDER BY nome ASC

    """)



    clientes = cursor.fetchall()



    conexao.close()



    return render_template(

        "novo_processo.html",

        clientes=clientes

    )





# =========================================

# VISUALIZAR PROCESSO

# =========================================



@app.route("/visualizar-processo/<int:id>")

def visualizar_processo(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT

            processos.id,

            processos.numero,

            processos.titulo,

            clientes.nome,

            processos.tipo,

            processos.status,

            processos.vara,

            processos.descricao

        FROM processos

        LEFT JOIN clientes

            ON processos.cliente_id = clientes.id

        WHERE processos.id = ?

    """, (id,))



    processo = cursor.fetchone()



    conexao.close()



    if processo is None:

        return "Processo não encontrado."



    return render_template(

        "visualizar_processo.html",

        processo=processo

    )





# =========================================

# EDITAR PROCESSO

# =========================================



@app.route("/editar-processo/<int:id>", methods=["GET", "POST"])

def editar_processo(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    if request.method == "POST":



        numero = request.form["numero"]

        titulo = request.form["titulo"]

        cliente_id = request.form["cliente_id"]

        tipo = request.form["tipo"]

        status = request.form["status"]

        vara = request.form["vara"]

        descricao = request.form["descricao"]



        cursor.execute("""

            UPDATE processos

            SET numero = ?,

                titulo = ?,

                cliente_id = ?,

                tipo = ?,

                status = ?,

                vara = ?,

                descricao = ?

            WHERE id = ?

        """, (

            numero,

            titulo,

            cliente_id,

            tipo,

            status,

            vara,

            descricao,

            id

        ))



        conexao.commit()

        conexao.close()



        return redirect(f"/visualizar-processo/{id}")



    cursor.execute("""

        SELECT

            id,

            numero,

            titulo,

            cliente_id,

            tipo,

            status,

            vara,

            descricao

        FROM processos

        WHERE id = ?

    """, (id,))



    processo = cursor.fetchone()



    if processo is None:

        conexao.close()

        return "Processo não encontrado."



    cursor.execute("""

        SELECT id, nome

        FROM clientes

        ORDER BY nome ASC

    """)



    clientes = cursor.fetchall()



    conexao.close()



    return render_template(

        "editar_processo.html",

        processo=processo,

        clientes=clientes

    )





# =========================================

# EXCLUIR PROCESSO

# =========================================



@app.route("/excluir-processo/<int:id>", methods=["POST"])

def excluir_processo(id):



    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute(

        "DELETE FROM processos WHERE id = ?",

        (id,)

    )



    conexao.commit()

    conexao.close()



    return redirect("/processos")



# =========================================

# PRAZOS

# =========================================



@app.route("/prazos")

def prazos():

    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT

            prazos.id,

            prazos.titulo,

            processos.numero,

            processos.titulo,

            prazos.data_vencimento,

            prazos.prioridade,

            prazos.status,

            prazos.observacao

        FROM prazos

        LEFT JOIN processos

            ON prazos.processo_id = processos.id

        ORDER BY prazos.data_vencimento ASC

    """)



    prazos = cursor.fetchall()



    conexao.close()



    return render_template(

        "prazos.html",

        prazos=prazos

    )





@app.route("/novo-prazo", methods=["GET", "POST"])

def novo_prazo():

    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    if request.method == "POST":



        titulo = request.form["titulo"]

        processo_id = request.form["processo_id"]

        data_vencimento = request.form["data_vencimento"]

        prioridade = request.form["prioridade"]

        status = request.form["status"]

        observacao = request.form["observacao"]



        cursor.execute("""

            INSERT INTO prazos

            (

                titulo,

                processo_id,

                data_vencimento,

                prioridade,

                status,

                observacao

            )

            VALUES (?, ?, ?, ?, ?, ?)

        """, (

            titulo,

            processo_id,

            data_vencimento,

            prioridade,

            status,

            observacao

        ))



        conexao.commit()

        conexao.close()



        return redirect("/prazos")



    cursor.execute("""

        SELECT id, numero, titulo

        FROM processos

        ORDER BY id DESC

    """)



    processos = cursor.fetchall()



    conexao.close()



    return render_template(

        "novo_prazo.html",

        processos=processos

    )



@app.route("/visualizar-prazo/<int:id>")

def visualizar_prazo(id):

    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute("""

        SELECT

            prazos.id,

            prazos.titulo,

            processos.numero,

            processos.titulo,

            prazos.data_vencimento,

            prazos.prioridade,

            prazos.status,

            prazos.observacao

        FROM prazos

        LEFT JOIN processos

            ON prazos.processo_id = processos.id

        WHERE prazos.id = ?

    """, (id,))



    prazo = cursor.fetchone()



    conexao.close()



    if prazo is None:

        return "Prazo não encontrado."



    return render_template(

        "visualizar_prazo.html",

        prazo=prazo

    )





@app.route("/editar-prazo/<int:id>", methods=["GET", "POST"])

def editar_prazo(id):

    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    if request.method == "POST":



        titulo = request.form["titulo"]

        processo_id = request.form["processo_id"]

        data_vencimento = request.form["data_vencimento"]

        prioridade = request.form["prioridade"]

        status = request.form["status"]

        observacao = request.form["observacao"]



        cursor.execute("""

            UPDATE prazos

            SET

                titulo = ?,

                processo_id = ?,

                data_vencimento = ?,

                prioridade = ?,

                status = ?,

                observacao = ?

            WHERE id = ?

        """, (

            titulo,

            processo_id,

            data_vencimento,

            prioridade,

            status,

            observacao,

            id

        ))



        conexao.commit()

        conexao.close()



        return redirect(f"/visualizar-prazo/{id}")



    cursor.execute("""

        SELECT

            id,

            titulo,

            processo_id,

            data_vencimento,

            prioridade,

            status,

            observacao

        FROM prazos

        WHERE id = ?

    """, (id,))



    prazo = cursor.fetchone()



    cursor.execute("""

        SELECT

            id,

            numero,

            titulo

        FROM processos

        ORDER BY id DESC

    """)



    processos = cursor.fetchall()



    conexao.close()



    if prazo is None:

        return "Prazo não encontrado."



    return render_template(

        "editar_prazo.html",

        prazo=prazo,

        processos=processos

    )





@app.route("/excluir-prazo/<int:id>", methods=["POST"])

def excluir_prazo(id):

    if "usuario_id" not in session:

        return redirect("/login")



    conexao = sqlite3.connect("jurisflow.db")

    cursor = conexao.cursor()



    cursor.execute(

        "DELETE FROM prazos WHERE id = ?",

        (id,)

    )



    conexao.commit()

    conexao.close()



    return redirect("/prazos")



# =========================================
# DOCUMENTOS
# =========================================

DOCUMENTOS_UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads", "documentos")
os.makedirs(DOCUMENTOS_UPLOAD_DIR, exist_ok=True)

def criar_tabela_documentos():
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS documentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            tipo TEXT,
            processo_id INTEGER,
            data_documento TEXT,
            descricao TEXT,
            nome_arquivo TEXT,
            FOREIGN KEY (processo_id) REFERENCES processos(id)
        )
    """)
    conexao.commit()
    conexao.close()

@app.route("/documentos")
def documentos():
    if "usuario_id" not in session:
        return redirect("/login")
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    cursor.execute("""
        SELECT documentos.id, documentos.titulo, documentos.tipo,
               processos.numero, processos.titulo, documentos.data_documento,
               documentos.descricao, documentos.nome_arquivo
        FROM documentos
        LEFT JOIN processos ON documentos.processo_id = processos.id
        ORDER BY documentos.id DESC
    """)
    documentos_lista = cursor.fetchall()
    conexao.close()
    return render_template("documentos.html", documentos=documentos_lista)

@app.route("/novo-documento", methods=["GET", "POST"])
def novo_documento():
    if "usuario_id" not in session:
        return redirect("/login")
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        tipo = request.form.get("tipo", "").strip()
        processo_id = request.form.get("processo_id") or None
        data_documento = request.form.get("data_documento", "").strip()
        descricao = request.form.get("descricao", "").strip()
        arquivo = request.files.get("arquivo")
        nome_arquivo = None
        if arquivo and arquivo.filename:
            nome_seguro = secure_filename(arquivo.filename)
            if nome_seguro:
                nome_arquivo = nome_seguro
                arquivo.save(os.path.join(DOCUMENTOS_UPLOAD_DIR, nome_arquivo))
        cursor.execute("""
            INSERT INTO documentos (titulo, tipo, processo_id, data_documento, descricao, nome_arquivo)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (titulo, tipo, processo_id, data_documento, descricao, nome_arquivo))
        conexao.commit()
        conexao.close()
        return redirect("/documentos")
    cursor.execute("SELECT id, numero, titulo FROM processos ORDER BY id DESC")
    processos = cursor.fetchall()
    conexao.close()
    return render_template("novo_documento.html", processos=processos)

@app.route("/visualizar-documento/<int:id>")
def visualizar_documento(id):
    if "usuario_id" not in session:
        return redirect("/login")
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    cursor.execute("""
        SELECT documentos.id, documentos.titulo, documentos.tipo,
               processos.numero, processos.titulo, documentos.data_documento,
               documentos.descricao, documentos.nome_arquivo
        FROM documentos
        LEFT JOIN processos ON documentos.processo_id = processos.id
        WHERE documentos.id = ?
    """, (id,))
    documento = cursor.fetchone()
    conexao.close()
    if documento is None:
        return "Documento não encontrado.", 404
    return render_template("visualizar_documento.html", documento=documento)

@app.route("/editar-documento/<int:id>", methods=["GET", "POST"])
def editar_documento(id):
    if "usuario_id" not in session:
        return redirect("/login")
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        tipo = request.form.get("tipo", "").strip()
        processo_id = request.form.get("processo_id") or None
        data_documento = request.form.get("data_documento", "").strip()
        descricao = request.form.get("descricao", "").strip()
        cursor.execute("SELECT nome_arquivo FROM documentos WHERE id = ?", (id,))
        atual = cursor.fetchone()
        nome_arquivo = atual[0] if atual else None
        arquivo = request.files.get("arquivo")
        if arquivo and arquivo.filename:
            nome_seguro = secure_filename(arquivo.filename)
            if nome_seguro:
                if nome_arquivo:
                    antigo = os.path.join(DOCUMENTOS_UPLOAD_DIR, nome_arquivo)
                    if os.path.exists(antigo):
                        os.remove(antigo)
                nome_arquivo = nome_seguro
                arquivo.save(os.path.join(DOCUMENTOS_UPLOAD_DIR, nome_arquivo))
        cursor.execute("""
            UPDATE documentos SET titulo=?, tipo=?, processo_id=?, data_documento=?, descricao=?, nome_arquivo=?
            WHERE id=?
        """, (titulo, tipo, processo_id, data_documento, descricao, nome_arquivo, id))
        conexao.commit()
        conexao.close()
        return redirect(f"/visualizar-documento/{id}")
    cursor.execute("SELECT id, titulo, tipo, processo_id, data_documento, descricao, nome_arquivo FROM documentos WHERE id = ?", (id,))
    documento = cursor.fetchone()
    cursor.execute("SELECT id, numero, titulo FROM processos ORDER BY id DESC")
    processos = cursor.fetchall()
    conexao.close()
    if documento is None:
        return "Documento não encontrado.", 404
    return render_template("editar_documento.html", documento=documento, processos=processos)

@app.route("/excluir-documento/<int:id>", methods=["POST"])
def excluir_documento(id):
    if "usuario_id" not in session:
        return redirect("/login")
    conexao = sqlite3.connect("jurisflow.db")
    cursor = conexao.cursor()
    cursor.execute("SELECT nome_arquivo FROM documentos WHERE id = ?", (id,))
    documento = cursor.fetchone()
    if documento and documento[0]:
        caminho = os.path.join(DOCUMENTOS_UPLOAD_DIR, documento[0])
        if os.path.exists(caminho):
            os.remove(caminho)
    cursor.execute("DELETE FROM documentos WHERE id = ?", (id,))
    conexao.commit()
    conexao.close()
    return redirect("/documentos")

@app.route("/documentos/arquivo/<path:nome_arquivo>")
def arquivo_documento(nome_arquivo):
    if "usuario_id" not in session:
        return redirect("/login")
    return send_from_directory(DOCUMENTOS_UPLOAD_DIR, nome_arquivo, as_attachment=False)


# =========================================

# INICIAR SISTEMA

# =========================================



if __name__ == "__main__":



    criar_tabela_processos()



    criar_tabela_prazos()

    criar_tabela_documentos()



    app.run(debug=True)


